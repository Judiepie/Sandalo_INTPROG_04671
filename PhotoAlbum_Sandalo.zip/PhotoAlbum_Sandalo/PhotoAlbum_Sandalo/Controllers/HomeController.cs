using Microsoft.AspNetCore.Mvc;
using PhotoAlbum_Sandalo.Models;
using System.Diagnostics;

namespace PhotoAlbum_Sandalo.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult FIGHTER()
        {
            return View();
        }
        public IActionResult TANK()
        {
            return View();
        }
        public IActionResult MAGE()
        {
            return View();
        }
        public IActionResult ASSASSIN()
        {
            return View();
        }
        public IActionResult MARKSMAN()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
